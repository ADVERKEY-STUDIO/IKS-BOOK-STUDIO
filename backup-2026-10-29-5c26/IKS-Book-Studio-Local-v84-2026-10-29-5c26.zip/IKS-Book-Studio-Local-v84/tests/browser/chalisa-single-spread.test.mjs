import { singleBook } from '../fixtures/chalisa-single-spread.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
import {unzipSync, zipSync, strToU8} from 'fflate';
const require=createRequire(import.meta.url), appUrl=process.env.IKS_APP_URL;

test('Approved single-chaupai workflow: samples, import, preview, edit, recovery and export', {skip:!appUrl,timeout:120000}, async()=>{
 const {chromium}=require(process.env.IKS_PLAYWRIGHT_MODULE||'playwright');
 const browser=await chromium.launch({headless:true});
 try {
  const page=await browser.newPage({viewport:{width:1440,height:1000}}), errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.goto(`${appUrl}/template-studio`);
  await page.getByText('Your books will appear here. Saved on this browser; download a ZIP for backup.',{exact:true}).waitFor();
  await page.locator('.children-gallery article').filter({hasText:'The Never Starting Tale of Jack and the Beanstalk'}).getByRole('button',{name:'Use template',exact:true}).click();
  assert.equal(await page.getByLabel('Passage grouping',{exact:true}).inputValue(),'chalisa');
  assert.equal(await page.getByLabel('Reader age / audience',{exact:true}).inputValue(),'Ages 9–14');
  await page.getByLabel('Book title',{exact:true}).fill('Durga Chalisa test');
  await page.getByLabel('Choose your PDF or DOCX').setInputFiles({name:'source.pdf',mimeType:'application/pdf',buffer:Buffer.from('Original chaupais')});
  await page.getByLabel('Book content reference (optional)',{exact:true}).setInputFiles({name:'reference.pdf',mimeType:'application/pdf',buffer:Buffer.from('Prepared meanings and morals')});
  assert.match(await page.getByLabel('Detailed book prompt').inputValue(),/COPY VERSES AND MEANINGS; WRITE SHORT BILINGUAL MORALS/);
  await page.getByRole('button',{name:'Save book now',exact:true}).click();
  await page.reload();
  await page.getByRole('button',{name:'Durga Chalisa test · 0 spreads',exact:true}).click();
  await page.getByRole('button',{name:'Remove content reference',exact:true}).waitFor();
  async function request() {
   const downloading=page.waitForEvent('download');
   await page.getByRole('button',{name:'Download request ZIP',exact:true}).click();
   return unzipSync(new Uint8Array(await readFile(await (await downloading).path())));
  }
  const referenceEntries=await request();
  assert.equal(new TextDecoder().decode(referenceEntries['content-reference/reference.pdf']),'Prepared meanings and morals');
  assert.equal(new TextDecoder().decode(referenceEntries['START-HERE.txt']),await page.getByLabel('Detailed book prompt').inputValue());
  await page.getByRole('button',{name:'Remove content reference',exact:true}).click();
  const entries=await request(), prompt=new TextDecoder().decode(entries['START-HERE.txt']);
  assert.ok(!entries['content-reference/reference.pdf']);
  assert.match(prompt,/NO CONTENT REFERENCE/);
  assert.match(prompt,/batches of at most FOUR/);
  const id=prompt.match(/"projectId": "([^"]+)"/)[1];
  const book={...singleBook(3),projectId:id,title:'Durga Chalisa test',bookSections:[{kind:'introduction',title:'Reading together',body:'Supplied introduction.\n\nRead one verse together.',sourceReference:'Introduction.pdf'},{kind:'aarti',title:'Aarti',body:'Supplied verse.\n\nHindi and English meanings.',sourceReference:'Aarti source'}],glossary:[{term:'ज्योति',hindi:'प्रकाश।',english:'Light.',sourceReference:'Chaupai 2'}]};
  const upload=async data=>page.getByLabel('Import ChatGPT’s ZIP or book.json').setInputFiles({name:'book.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});
  await upload({...book,pages:book.pages.map(p=>({...p,chalisaPages:p.chalisaPages.map(leaf=>({...leaf,meaning:'Only one English meaning'}))}))});
  await page.getByRole('alert').filter({hasText:'required labels'}).waitFor();
  const image=Buffer.from(await page.evaluate(()=>{const c=document.createElement('canvas');c.width=1200;c.height=600;const ctx=c.getContext('2d');ctx.fillStyle='#fbf6e8';ctx.fillRect(0,0,1200,600);
   // A continuous scene crosses the fold; reading regions retain painted sky.
   const sky=ctx.createLinearGradient(0,0,0,600);sky.addColorStop(0,'#fff5d9');sky.addColorStop(1,'#f8de9b');ctx.fillStyle=sky;ctx.fillRect(0,0,1200,600);
   ctx.fillStyle='#8bb8a6';ctx.beginPath();ctx.moveTo(0,470);ctx.quadraticCurveTo(450,360,650,470);ctx.quadraticCurveTo(900,380,1200,445);ctx.lineTo(1200,600);ctx.lineTo(0,600);ctx.fill();
   ctx.fillStyle='#355b52';ctx.fillRect(0,0,45,600);ctx.fillRect(1160,0,40,600);return c.toDataURL().split(',')[1];}),'base64');
  await page.getByLabel('Import ChatGPT’s ZIP or book.json').setInputFiles({name:'checkpoint.zip',mimeType:'application/zip',buffer:Buffer.from(zipSync({'book.json':strToU8(JSON.stringify(book)),'images/spread-1.png':image,'images/character-reference.png':image,'passage-map.txt':strToU8('Saved passage map'),'progress.txt':strToU8('Pending spread-2.png')}))});
  await page.getByRole('button',{name:'Read book',exact:true}).waitFor();
  await page.getByRole('button',{name:'Book settings',exact:true}).click();
  await page.getByLabel('Glossary 1 english',{exact:true}).fill('Divine light.');
  await page.getByLabel('Section 1 body',{exact:true}).fill('Approved introduction.\n\nRead with your family.');
  await page.getByRole('button',{name:'Book settings',exact:true}).click();
  await page.getByRole('button',{name:'Text & layout',exact:true}).click();
  assert.equal(await page.getByLabel('Spread chaupai',{exact:true}).inputValue(),book.pages[0].chalisaPages[0].original);
  assert.equal(await page.getByLabel('Right chaupai',{exact:true}).count(),0);
  await page.getByLabel('Spread meanings and morals',{exact:true}).fill(book.pages[0].chalisaPages[0].meaning.replace('Mother Durga','Mother Durga lovingly'));
  const preview=page.frameLocator('iframe.ts-spread-frame');
  await preview.locator('.planned-text').first().waitFor();
  await preview.locator('body').evaluate(()=>document.fonts.ready);
  const regions=await preview.locator('.planned-text').evaluateAll(nodes=>nodes.filter(n=>n.textContent.trim()).map(n=>({text:n.textContent,x:n.offsetLeft,w:n.offsetWidth,sw:n.scrollWidth,h:n.clientHeight,sh:n.scrollHeight,parent:n.parentElement.clientWidth})));
  assert.equal(await preview.locator('.chalisa-verse').first().evaluate(el=>getComputedStyle(el).color),'rgb(139, 54, 40)');
  assert.equal(regions.length,1);assert.ok(regions[0].x>regions[0].parent/2);
  assert.ok(regions.every(r=>r.sw<=r.w+2&&r.sh<=r.h+2),'The complete chaupai and all four sections fit');
  assert.equal(await page.getByText(/reading order needs review/).count(),0);
  const art=await preview.locator('.planned-art').evaluate(im=>({w:im.clientWidth,h:im.clientHeight,pw:im.parentElement.clientWidth,ph:im.parentElement.clientHeight}));
  assert.equal(art.w,art.pw);assert.equal(art.h,art.ph);
  const scenes=await preview.locator('.planned-art-frame').evaluateAll(nodes=>nodes.map(n=>({w:n.offsetWidth/n.parentElement.clientWidth,h:n.offsetHeight/n.parentElement.clientHeight})));
  assert.equal(scenes.length,1);assert.equal(scenes[0].w,1);assert.equal(scenes[0].h,1);
  await preview.locator('.planned-spread').screenshot({path:'/tmp/chalisa-single-spread-preview.png'});
  await page.getByRole('button',{name:'Artwork & imports',exact:true}).click();
  const downloading=page.waitForEvent('download');
  await page.getByRole('button',{name:'Download images prompt',exact:true}).click();
  const continuation=await readFile(await (await downloading).path(),'utf8');
  assert.match(continuation,/images\/spread-2.png/);assert.doesNotMatch(continuation,/images\/spread-1.png/);
  assert.match(continuation,/Meaning and moral context:/);assert.match(continuation,/UP TO 4 PER REQUEST/);
  await page.getByRole('button',{name:'Review layouts & rebuild artwork',exact:true}).click();
  await page.getByRole('region',{name:'Review spread layout plan'}).waitFor();
  assert.equal(await page.locator('.ts-layout-diagram').count(),3);
  await page.getByRole('button',{name:'Close layout plan',exact:true}).click();
  await page.getByRole('button',{name:'Export book',exact:true}).click();
  const exportDownload=page.waitForEvent('download');
  await page.getByRole('button',{name:'Download editable ZIP',exact:true}).click();
  const exported=unzipSync(new Uint8Array(await readFile(await (await exportDownload).path())));
  const restored=JSON.parse(new TextDecoder().decode(exported['book.json']));
  assert.equal(restored.glossary[0].english,'Divine light.');
  assert.equal(restored.bookSections[0].body,'Approved introduction.\n\nRead with your family.');
  assert.equal(restored.bookSections[1].kind,'aarti');
  assert.equal(restored.pages[0].chalisaPages.length,1);
  assert.equal(restored.pages[1].chalisaPages.length,1);
  assert.match(restored.pages[0].chalisaPages[0].meaning,/Mother Durga lovingly/);
  const manuscript=new TextDecoder().decode(exported['manuscript.md']);
  assert.match(manuscript,/Divine light/);
  assert.ok(manuscript.indexOf('Approved introduction')<manuscript.indexOf('### Two-page spread'));
  assert.ok(manuscript.indexOf('## Aarti')<manuscript.indexOf('Divine light'));
  const exportHtml=new TextDecoder().decode(exported['preview.html']);
  assert.match(exportHtml,/class="spread glossary-spread"/);
  assert.match(manuscript,/### Two-page spread/);
  assert.doesNotMatch(manuscript,/### Right page|### Left page/);
  assert.ok(entries['template-references/approved-cloud-right.png']);
  assert.ok(entries['template-references/approved-cloud-left.png']);
  assert.deepEqual(errors,[]);
 } finally { await browser.close(); }
});

test('all single-chaupai cloud reading arrangements fit actual bilingual text at 14 pt', {skip:!appUrl,timeout:60000}, async()=>{
 const {parseTemplateBook,renderTemplateBook}=await import('../../lib/template-book.ts');
 const {chalisaSingleBlueprints}=await import('../../lib/template-layouts.ts');
 const {chromium}=require(process.env.IKS_PLAYWRIGHT_MODULE||'playwright');
 const browser=await chromium.launch({headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1600,height:1000}});
  let proofHtml='';
  await page.route(`${appUrl}/chalisa-single-reading-proof`,route=>route.fulfill({contentType:'text/html',body:proofHtml}));
  for(const layout of chalisaSingleBlueprints){
   const raw=singleBook(1);raw.pages[0].blueprint=layout.id;
   proofHtml=renderTemplateBook(parseTemplateBook(raw),{},'/fonts/book-sanskrit.ttf');
   await page.goto(`${appUrl}/chalisa-single-reading-proof`);
   await page.evaluate(()=>document.fonts.ready);
   const regions=await page.locator('.planned-text').evaluateAll(nodes=>nodes.filter(n=>n.textContent.trim()).map(n=>({w:n.clientWidth,sw:n.scrollWidth,h:n.clientHeight,sh:n.scrollHeight})));
   assert.equal(regions.length,1);
   assert.ok(regions.every(r=>r.sw<=r.w+2&&r.sh<=r.h+2),`${layout.id}: the verse and four sections fit`);
  }
 }finally{await browser.close();}
});
