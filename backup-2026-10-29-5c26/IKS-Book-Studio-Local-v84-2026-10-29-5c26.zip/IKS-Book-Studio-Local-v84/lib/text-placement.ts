import { hasCompactChalisaText } from './chalisa-pages.ts';
import type { Region } from './template-layouts.ts';
/** Percent coordinates remain portable across preview, print and differently sized screens. */
export function parseTextPositions(value:unknown,count:number):Region[]|undefined {
 if(value===undefined)return;
 if(!Array.isArray(value)||value.length!==count)throw Error('Text positions must match the spread’s text boxes.');
 return value.map(v=>{
  if(!v||typeof v!=='object'||!['x','y','w','h'].every(k=>typeof v[k]==='number'&&Number.isFinite(v[k])))throw Error('Invalid text position.');
  const {x,y,w,h}=v;
  if(x<0||y<0||w<1||h<1||x+w>100.001||y+h>100.001)throw Error('Text boxes must stay within the page.');
  return {x,y,w,h};
 });
}
export function moveTextBox(box:Region,dx:number,dy:number,resize=false):Region {
 const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
 return resize?{...box,w:clamp(box.w+dx,1,100-box.x),h:clamp(box.h+dy,1,100-box.y)}:{...box,x:clamp(box.x+dx,0,100-box.w),y:clamp(box.y+dy,0,100-box.h)};
}
/** Measure in unscaled layout pixels, so browser zoom does not alter the saved result. */
export function fitTextPositions(spread:HTMLElement,boxes:Region[]):Region[]{
 return boxes.map((box,i)=>{
  const el=spread.querySelector<HTMLElement>(`[data-text-region="${i+1}"]`);
  if(!el||!spread.clientHeight||!spread.clientWidth)return box;
  if(el.scrollHeight<=el.clientHeight+2&&el.scrollWidth<=el.clientWidth+2)return box;
  // The illustrated composition has fixed reading reservations; overflowing text must
  // stay visible to review rather than expanding across the matching artwork.
  if(hasCompactChalisaText(spread.dataset.blueprint))return box;
  const facing=spread.dataset.blueprint==='chalisa-facing-pages';
  const maxRight=facing?(i===0?48:98):100;
  const maxBottom=facing?93:100;
  const x=facing?Math.min(maxRight-1,Math.max(i===0?2:52,box.x)):box.x;
  const y=facing?Math.min(maxBottom-1,box.y):box.y;
  const w=Math.min(facing?maxRight-x:100,Math.max(box.w,(el.scrollWidth+2)/spread.clientWidth*100));
  const h=Math.min(facing?maxBottom-y:100,Math.max(box.h,(el.scrollHeight+3)/spread.clientHeight*100));
  return {x:Math.min(x,100-w),y:Math.min(y,100-h),w,h};
 });
}
